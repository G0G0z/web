import { Router, type IRouter } from "express";
import healthRouter from "./health";
import categoriesRouter from "./categories";
import providersRouter from "./providers";
import serviceRequestsRouter from "./serviceRequests";
import statsRouter from "./stats";

const router: IRouter = Router();

router.use(healthRouter);
router.use(statsRouter);
router.use(categoriesRouter);
router.use(providersRouter);
router.use(serviceRequestsRouter);

export default router;
