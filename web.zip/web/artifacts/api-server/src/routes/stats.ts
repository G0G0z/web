import { Router, type IRouter } from "express";
import { sql, eq } from "drizzle-orm";
import { db, categoriesTable, providersTable, platformCountersTable } from "@workspace/db";
import { GetStatsSummaryResponse } from "@workspace/api-zod";

const router: IRouter = Router();

// Kapımda Türkiye genelinde hizmet verir; bu yüzden "kaç şehirde" istatistiği
// mevcut usta kayıtlarının bulunduğu şehir sayısı yerine Türkiye'deki toplam
// il sayısını (81) gösterir.
const TOTAL_TURKIYE_CITY_COUNT = 81;

// Ana sayfadaki "Tamamlanan İş" sayısı, gerçek toplamın üzerine, zamanla
// (her 5 dakikada bir) otomatik artan kalıcı bir "bonus" değeri ekler.
// Bonus değeri veritabanında saklanır, böylece sunucu yeniden başlasa da
// son sayı hatırlanır ve kaldığı yerden artmaya devam eder.
const COMPLETED_JOBS_BONUS_KEY = "completed_jobs_bonus";
const TICK_INTERVAL_MS = 5 * 60 * 1000;
const INCREMENT_PER_TICK = 1;

async function getAndAdvanceCompletedJobsBonus(): Promise<number> {
  await db
    .insert(platformCountersTable)
    .values({ key: COMPLETED_JOBS_BONUS_KEY, value: 0 })
    .onConflictDoNothing();

  const [counter] = await db
    .select()
    .from(platformCountersTable)
    .where(eq(platformCountersTable.key, COMPLETED_JOBS_BONUS_KEY));

  if (!counter) return 0;

  const elapsedMs = Date.now() - counter.updatedAt.getTime();
  const ticks = Math.floor(elapsedMs / TICK_INTERVAL_MS);

  if (ticks <= 0) {
    return counter.value;
  }

  const newValue = counter.value + ticks * INCREMENT_PER_TICK;
  const newUpdatedAt = new Date(counter.updatedAt.getTime() + ticks * TICK_INTERVAL_MS);

  await db
    .update(platformCountersTable)
    .set({ value: newValue, updatedAt: newUpdatedAt })
    .where(eq(platformCountersTable.key, COMPLETED_JOBS_BONUS_KEY));

  return newValue;
}

router.get("/stats/summary", async (_req, res): Promise<void> => {
  const [providerStats] = await db
    .select({
      totalProviders: sql<number>`count(*)::int`,
      totalCompletedJobs: sql<number>`coalesce(sum(${providersTable.completedJobs}), 0)::int`,
    })
    .from(providersTable);

  const [categoryStats] = await db
    .select({ totalCategories: sql<number>`count(*)::int` })
    .from(categoriesTable);

  const completedJobsBonus = await getAndAdvanceCompletedJobsBonus();

  res.json(
    GetStatsSummaryResponse.parse({
      totalProviders: providerStats?.totalProviders ?? 0,
      totalCompletedJobs: (providerStats?.totalCompletedJobs ?? 0) + completedJobsBonus,
      totalCategories: categoryStats?.totalCategories ?? 0,
      totalCities: TOTAL_TURKIYE_CITY_COUNT,
    }),
  );
});

export default router;
