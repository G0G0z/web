import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, categoriesTable, serviceRequestsTable } from "@workspace/db";
import { CreateServiceRequestBody, CreateServiceRequestResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.post("/service-requests", async (req, res): Promise<void> => {
  const parsed = CreateServiceRequestBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [category] = await db
    .select()
    .from(categoriesTable)
    .where(eq(categoriesTable.slug, parsed.data.categorySlug));

  if (!category) {
    res.status(400).json({ error: "Unknown category" });
    return;
  }

  const [request] = await db
    .insert(serviceRequestsTable)
    .values({
      categoryId: category.id,
      customerName: parsed.data.customerName,
      customerPhone: parsed.data.customerPhone,
      city: parsed.data.city,
      district: parsed.data.district ?? null,
      description: parsed.data.description ?? "",
    })
    .returning();

  await db
    .update(categoriesTable)
    .set({ requestCount: category.requestCount + 1 })
    .where(eq(categoriesTable.id, category.id));

  res.status(201).json(
    CreateServiceRequestResponse.parse({
      id: request!.id,
      categorySlug: category.slug,
      categoryName: category.name,
      customerName: request!.customerName,
      customerPhone: request!.customerPhone,
      city: request!.city,
      district: request!.district,
      description: request!.description,
      status: request!.status,
      createdAt: request!.createdAt,
    }),
  );
});

export default router;
