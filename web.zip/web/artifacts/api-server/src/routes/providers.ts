import { Router, type IRouter } from "express";
import { and, desc, eq, ilike, or } from "drizzle-orm";
import { db, categoriesTable, providersTable, reviewsTable } from "@workspace/db";
import {
  GetProviderParams,
  GetProviderResponse,
  ListProvidersQueryParams,
  ListProvidersResponse,
  ListProviderReviewsParams,
  ListProviderReviewsResponse,
  ListTopRatedProvidersQueryParams,
  ListTopRatedProvidersResponse,
} from "@workspace/api-zod";
import { serializeProvider } from "../lib/serializers";

const router: IRouter = Router();

router.get("/providers/top-rated", async (req, res): Promise<void> => {
  const query = ListTopRatedProvidersQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const limit = query.data.limit ?? 6;

  const rows = await db
    .select({ provider: providersTable, category: categoriesTable })
    .from(providersTable)
    .innerJoin(categoriesTable, eq(providersTable.categoryId, categoriesTable.id))
    .orderBy(desc(providersTable.rating), desc(providersTable.reviewCount))
    .limit(limit);

  const data = rows.map((row) => serializeProvider(row.provider, row.category));
  res.json(ListTopRatedProvidersResponse.parse(data));
});

router.get("/providers/:id", async (req, res): Promise<void> => {
  const params = GetProviderParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const row = await db
    .select({ provider: providersTable, category: categoriesTable })
    .from(providersTable)
    .innerJoin(categoriesTable, eq(providersTable.categoryId, categoriesTable.id))
    .where(eq(providersTable.id, params.data.id));

  if (row.length === 0) {
    res.status(404).json({ error: "Provider not found" });
    return;
  }

  res.json(GetProviderResponse.parse(serializeProvider(row[0]!.provider, row[0]!.category)));
});

router.get("/providers/:id/reviews", async (req, res): Promise<void> => {
  const params = ListProviderReviewsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [provider] = await db
    .select()
    .from(providersTable)
    .where(eq(providersTable.id, params.data.id));

  if (!provider) {
    res.status(404).json({ error: "Provider not found" });
    return;
  }

  const rows = await db
    .select()
    .from(reviewsTable)
    .where(eq(reviewsTable.providerId, provider.id))
    .orderBy(desc(reviewsTable.createdAt));

  res.json(ListProviderReviewsResponse.parse(rows));
});

router.get("/providers", async (req, res): Promise<void> => {
  const query = ListProvidersQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const { category, city, search } = query.data;

  const conditions = [];
  if (category) {
    conditions.push(eq(categoriesTable.slug, category));
  }
  if (city) {
    conditions.push(ilike(providersTable.city, city));
  }
  if (search) {
    conditions.push(
      or(
        ilike(providersTable.name, `%${search}%`),
        ilike(providersTable.businessName, `%${search}%`),
      ),
    );
  }

  const rows = await db
    .select({ provider: providersTable, category: categoriesTable })
    .from(providersTable)
    .innerJoin(categoriesTable, eq(providersTable.categoryId, categoriesTable.id))
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(providersTable.rating));

  const data = rows.map((row) => serializeProvider(row.provider, row.category));
  res.json(ListProvidersResponse.parse(data));
});

export default router;
