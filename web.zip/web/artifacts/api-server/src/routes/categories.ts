import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, categoriesTable, providersTable } from "@workspace/db";
import {
  GetCategoryParams,
  GetCategoryResponse,
  ListCategoriesResponse,
  ListCategoryProvidersParams,
  ListCategoryProvidersResponse,
} from "@workspace/api-zod";
import { serializeProvider } from "../lib/serializers";

const router: IRouter = Router();

router.get("/categories", async (_req, res): Promise<void> => {
  const rows = await db.select().from(categoriesTable).orderBy(categoriesTable.name);
  res.json(ListCategoriesResponse.parse(rows));
});

router.get("/categories/:slug", async (req, res): Promise<void> => {
  const params = GetCategoryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [category] = await db
    .select()
    .from(categoriesTable)
    .where(eq(categoriesTable.slug, params.data.slug));

  if (!category) {
    res.status(404).json({ error: "Category not found" });
    return;
  }

  res.json(GetCategoryResponse.parse(category));
});

router.get("/categories/:slug/providers", async (req, res): Promise<void> => {
  const params = ListCategoryProvidersParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [category] = await db
    .select()
    .from(categoriesTable)
    .where(eq(categoriesTable.slug, params.data.slug));

  if (!category) {
    res.status(404).json({ error: "Category not found" });
    return;
  }

  const rows = await db
    .select()
    .from(providersTable)
    .where(eq(providersTable.categoryId, category.id));

  const data = rows.map((row) => serializeProvider(row, category));
  res.json(ListCategoryProvidersResponse.parse(data));
});

export default router;
