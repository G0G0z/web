import type { CategoryRow, ProviderRow } from "@workspace/db";

export function serializeProvider(provider: ProviderRow, category: CategoryRow) {
  return {
    id: provider.id,
    name: provider.name,
    businessName: provider.businessName,
    categorySlug: category.slug,
    categoryName: category.name,
    city: provider.city,
    district: provider.district,
    rating: Number(provider.rating),
    reviewCount: provider.reviewCount,
    completedJobs: provider.completedJobs,
    avatarUrl: provider.avatarUrl ?? null,
    bio: provider.bio,
    verified: provider.verified,
    yearsExperience: provider.yearsExperience,
    startingPrice: provider.startingPrice,
  };
}
