import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, Router as WouterRouter } from 'wouter';

// Pages
import Home from '@/pages/Home';
import CategoryDetail from '@/pages/CategoryDetail';
import Providers from '@/pages/Providers';
import ProviderDetail from '@/pages/ProviderDetail';
import RequestService from '@/pages/RequestService';

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/kategori/:slug" component={CategoryDetail} />
      <Route path="/ustalar" component={Providers} />
      <Route path="/ustalar/:id" component={ProviderDetail} />
      <Route path="/hizmet-al" component={RequestService} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
