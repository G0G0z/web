import { useState } from 'react';

interface ProviderAvatarProps {
  avatarUrl?: string | null;
  businessName: string;
  className: string;
  fallbackClassName?: string;
  textClassName?: string;
}

/**
 * Renders a provider's photo, falling back to an initial-letter badge when
 * the URL is missing or the image fails to load (e.g. a dead/hotlink-blocked
 * external URL).
 */
export function ProviderAvatar({
  avatarUrl,
  businessName,
  className,
  fallbackClassName,
  textClassName,
}: ProviderAvatarProps) {
  const [failed, setFailed] = useState(false);

  if (!avatarUrl || failed) {
    return (
      <div className={fallbackClassName ?? className}>
        <span className={textClassName ?? 'font-display font-bold'}>{businessName.charAt(0)}</span>
      </div>
    );
  }

  return (
    <img
      src={avatarUrl}
      alt={businessName}
      className={className}
      onError={() => setFailed(true)}
    />
  );
}
