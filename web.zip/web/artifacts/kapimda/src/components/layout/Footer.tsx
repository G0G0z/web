import { HeartHandshake } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t border-border bg-card">
      <div className="container mx-auto px-4 md:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2 space-y-4">
            <div className="flex items-center gap-2">
              <div className="bg-primary/10 text-primary p-2 rounded-xl">
                <HeartHandshake className="w-5 h-5" />
              </div>
              <span className="font-display font-bold text-xl text-foreground">
                Kapımda
              </span>
            </div>
            <p className="text-muted-foreground max-w-sm">
              Güvenilir ve onaylı ustaları kapınıza getiriyoruz. Evinizin her türlü ihtiyacı için mahallenizin ustası bir tık uzağınızda.
            </p>
          </div>
          
          <div>
            <h4 className="font-display font-semibold mb-4">Hizmetlerimiz</h4>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li>Ev Temizliği</li>
              <li>Tesisat & Elektrik</li>
              <li>Nakliyat</li>
              <li>Özel Ders</li>
              <li>Tadilat & Boya</li>
            </ul>
          </div>

          <div>
            <h4 className="font-display font-semibold mb-4">İletişim</h4>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li>destek@kapimda.com</li>
              <li>0850 123 45 67</li>
              <li>Yardım Merkezi</li>
              <li>Sıkça Sorulan Sorular</li>
            </ul>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-border flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} Kapımda. Tüm hakları saklıdır.</p>
          <div className="flex gap-4">
            <span className="cursor-pointer hover:text-primary transition-colors">Gizlilik Politikası</span>
            <span className="cursor-pointer hover:text-primary transition-colors">Kullanım Şartları</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
