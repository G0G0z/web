import { Link, useLocation } from "wouter"
import { Home, Search, HeartHandshake, User, Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import { cn } from "@/lib/utils"

export function Navbar() {
  const [location] = useLocation()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  const navLinks = [
    { href: "/", label: "Ana Sayfa", icon: Home },
    { href: "/ustalar", label: "Hizmetler", icon: Search },
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-xl">
      <div className="container mx-auto px-4 md:px-6 flex h-20 items-center justify-between">
        <Link href="/" className="flex items-center gap-2 transition-transform hover:scale-105 active:scale-95" data-testid="link-home">
          <div className="bg-primary text-primary-foreground p-2 rounded-xl shadow-sm">
            <HeartHandshake className="w-6 h-6" />
          </div>
          <span className="font-display font-bold text-2xl tracking-tight text-foreground">
            Kapımda
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          <div className="flex gap-6">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "text-sm font-medium transition-colors hover:text-primary",
                  location === link.href ? "text-primary font-semibold" : "text-muted-foreground"
                )}
                data-testid={`link-nav-${link.href.replace('/', '') || 'home'}`}
              >
                {link.label}
              </Link>
            ))}
          </div>
          <div className="flex items-center gap-4 border-l border-border pl-6">
            <Link href="/hizmet-al" data-testid="link-request-service">
              <Button className="rounded-full shadow-md shadow-primary/20 transition-transform hover:-translate-y-0.5">
                Hizmet Talebi Oluştur
              </Button>
            </Link>
          </div>
        </nav>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden p-2 text-muted-foreground hover:text-foreground"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Nav */}
      {isMobileMenuOpen && (
        <div className="md:hidden border-b border-border bg-background px-4 py-4 space-y-4 animate-in slide-in-from-top-4">
          <nav className="flex flex-col space-y-3">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-colors",
                  location === link.href ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted text-muted-foreground"
                )}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <link.icon className="w-5 h-5" />
                {link.label}
              </Link>
            ))}
            <Link href="/hizmet-al" onClick={() => setIsMobileMenuOpen(false)}>
              <Button className="w-full mt-4 rounded-xl" size="lg">
                Hizmet Talebi Oluştur
              </Button>
            </Link>
          </nav>
        </div>
      )}
    </header>
  )
}
