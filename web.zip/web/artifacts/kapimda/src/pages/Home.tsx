import { Layout } from "@/components/layout/Layout"
import { useListCategories, useListTopRatedProviders, useGetStatsSummary } from "@workspace/api-client-react"
import { Link } from "wouter"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, ShieldCheck, MapPin, ArrowRight, Search } from "lucide-react"
import { getCategoryIcon } from "@/lib/categoryIcons"
import { ProviderAvatar } from "@/components/ProviderAvatar"

export default function Home() {
  const { data: stats } = useGetStatsSummary()
  const { data: categories, isLoading: isLoadingCategories } = useListCategories()
  const { data: topProviders, isLoading: isLoadingProviders } = useListTopRatedProviders({ limit: 4 })

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-primary/5 py-20 lg:py-32">
        <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/3 w-[800px] h-[800px] bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 translate-y-1/3 -translate-x-1/3 w-[600px] h-[600px] bg-accent/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="container relative z-10 mx-auto px-4 text-center">
          <Badge variant="secondary" className="mb-6 rounded-full px-4 py-1.5 text-sm font-medium border-primary/20 bg-white">
            <ShieldCheck className="w-4 h-4 text-primary mr-2" />
            Türkiye'nin Güvenilir Usta Ağı
          </Badge>
          <h1 className="mx-auto max-w-4xl font-display text-5xl font-bold tracking-tight text-foreground sm:text-6xl md:text-7xl">
            Mahallenizin Güvenilir Ustası <span className="text-primary relative whitespace-nowrap">
              Kapınızda
              <svg className="absolute -bottom-2 left-0 w-full h-3 text-accent" viewBox="0 0 100 10" preserveAspectRatio="none">
                <path d="M0 5 Q 50 10 100 5" stroke="currentColor" strokeWidth="3" fill="transparent"/>
              </svg>
            </span>
          </h1>
          <p className="mx-auto mt-8 max-w-2xl text-lg text-muted-foreground leading-relaxed">
            Temizlikten tesisata, elektrikten nakliyata... Evinizin her ihtiyacı için onaylı, güvenilir ve işinin ehli ustalar sadece birkaç tık uzağınızda.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/hizmet-al">
              <Button size="lg" className="w-full sm:w-auto h-14 px-8 text-base shadow-lg shadow-primary/20 rounded-2xl hover:scale-105 transition-transform">
                Hemen Usta Çağır
              </Button>
            </Link>
            <Link href="/ustalar">
              <Button size="lg" variant="outline" className="w-full sm:w-auto h-14 px-8 text-base rounded-2xl hover:scale-105 transition-transform bg-white/50 backdrop-blur-sm">
                <Search className="w-5 h-5 mr-2" />
                Hizmetleri İncele
              </Button>
            </Link>
          </div>
          
          {/* Stats Bar */}
          <div className="mt-20 max-w-4xl mx-auto bg-white/80 backdrop-blur-md border border-white rounded-3xl p-6 shadow-xl grid grid-cols-2 md:grid-cols-4 gap-8 divide-x divide-border/50">
            <div className="flex flex-col items-center">
              <span className="text-3xl font-display font-bold text-primary">{stats?.totalProviders || "500"}+</span>
              <span className="text-sm font-medium text-muted-foreground mt-1">Onaylı Usta</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-3xl font-display font-bold text-primary">{stats?.totalCompletedJobs || "5000"}+</span>
              <span className="text-sm font-medium text-muted-foreground mt-1">Tamamlanan İş</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-3xl font-display font-bold text-primary">{stats?.totalCategories || "20"}+</span>
              <span className="text-sm font-medium text-muted-foreground mt-1">Farklı Hizmet</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-3xl font-display font-bold text-primary">{stats?.totalCities || "81"}</span>
              <span className="text-sm font-medium text-muted-foreground mt-1">Şehirde</span>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section id="hizmet-kategorileri" className="py-24 container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">Neye İhtiyacınız Var?</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">En çok talep edilen hizmet kategorilerimizi inceleyin ve size uygun ustayı anında bulun.</p>
        </div>
        
        {isLoadingCategories ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {[1, 2, 3, 4, 5].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-8 flex flex-col items-center justify-center text-center h-48">
                  <div className="w-16 h-16 bg-muted rounded-2xl mb-4" />
                  <div className="h-4 bg-muted rounded w-24" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="relative -mx-4 overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_5%,black_95%,transparent)]">
            <div className="flex w-max gap-6 px-4 animate-marquee">
              {[...(categories ?? []), ...(categories ?? [])].map((category, i) => (
                <Link key={`${category.id}-${i}`} href={`/kategori/${category.slug}`} className="shrink-0 w-44">
                  <Card className="group cursor-pointer hover:shadow-lg hover:border-primary/50 transition-all duration-300 hover:-translate-y-1 bg-white">
                    <CardContent className="p-8 flex flex-col items-center justify-center text-center h-48">
                      <div className="w-16 h-16 rounded-2xl bg-primary/5 text-primary flex items-center justify-center mb-4 group-hover:bg-primary group-hover:text-white transition-colors duration-300">
                        {getCategoryIcon(category.slug)}
                      </div>
                      <h3 className="font-display font-semibold text-lg">{category.name}</h3>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* Top Providers Section */}
      <section className="py-24 bg-card">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-4">
            <div>
              <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">Ayın En İyi Ustaları</h2>
              <p className="text-muted-foreground max-w-2xl">Müşterilerden en yüksek puanları alan ve en çok tercih edilen ustalarımız.</p>
            </div>
            <Link href="/ustalar">
              <Button variant="ghost" className="text-primary hover:text-primary/80 group">
                Tümünü Gör 
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </div>

          {isLoadingProviders ? (
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
               {[1, 2, 3, 4].map(i => (
                 <Card key={i} className="animate-pulse">
                   <div className="h-32 bg-muted" />
                   <CardContent className="p-6 relative pt-12">
                     <div className="absolute -top-10 left-6 w-20 h-20 rounded-full bg-muted border-4 border-white" />
                     <div className="space-y-3">
                       <div className="h-5 bg-muted rounded w-3/4" />
                       <div className="h-4 bg-muted rounded w-1/2" />
                       <div className="h-10 bg-muted rounded w-full mt-4" />
                     </div>
                   </CardContent>
                 </Card>
               ))}
             </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {topProviders?.map((provider) => (
                <Link key={provider.id} href={`/ustalar/${provider.id}`}>
                  <Card className="group h-full flex flex-col hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white border-transparent hover:border-primary/20">
                    <div className="h-24 bg-primary/10 rounded-t-2xl relative overflow-hidden">
                      {/* Decorative pattern */}
                      <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)", backgroundSize: "16px 16px" }} />
                    </div>
                    <CardContent className="p-6 relative pt-12 flex-1 flex flex-col">
                      <div className="absolute -top-10 left-6">
                        <ProviderAvatar
                          avatarUrl={provider.avatarUrl}
                          businessName={provider.businessName}
                          className="w-20 h-20 rounded-full object-cover border-4 border-white shadow-md bg-white"
                          fallbackClassName="w-20 h-20 rounded-full bg-primary/10 text-primary flex items-center justify-center border-4 border-white shadow-md"
                          textClassName="font-display font-bold text-2xl"
                        />
                        {provider.verified && (
                          <div className="absolute bottom-0 right-0 bg-white rounded-full p-0.5" title="Onaylı Usta">
                            <ShieldCheck className="w-5 h-5 text-primary fill-primary/10" />
                          </div>
                        )}
                      </div>
                      
                      <div className="mb-4">
                        <h3 className="font-display font-bold text-lg leading-tight group-hover:text-primary transition-colors">{provider.businessName}</h3>
                        <p className="text-sm text-muted-foreground mt-1 line-clamp-1">{provider.categoryName}</p>
                      </div>

                      <div className="flex items-center gap-4 mb-6">
                        <div className="flex items-center gap-1.5 text-sm font-medium">
                          <Star className="w-4 h-4 fill-accent text-accent" />
                          {provider.rating.toFixed(1)} <span className="text-muted-foreground font-normal">({provider.reviewCount})</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                          <MapPin className="w-4 h-4" />
                          {provider.city}
                        </div>
                      </div>

                      <div className="mt-auto">
                        <Badge variant="secondary" className="w-full justify-center py-2 bg-secondary/50 font-medium">
                          {provider.completedJobs} İş Tamamladı
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* How it works */}
      <section className="py-24 container mx-auto px-4">
        <div className="bg-primary/5 rounded-[3rem] p-12 lg:p-20 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full opacity-30 pointer-events-none" style={{ backgroundImage: "radial-gradient(circle at 2px 2px, var(--color-primary) 1px, transparent 0)", backgroundSize: "32px 32px" }} />
          
          <div className="text-center mb-16 relative z-10">
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">Nasıl Çalışır?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">Sadece 3 basit adımda ihtiyacınız olan ustaya ulaşın.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative z-10">
            <div className="flex flex-col items-center text-center">
              <div className="w-20 h-20 bg-white rounded-2xl shadow-xl flex items-center justify-center text-primary font-display font-bold text-3xl mb-6 relative">
                1
                <div className="absolute -right-4 top-1/2 -translate-y-1/2 hidden md:block text-border">
                  <ArrowRight className="w-8 h-8" />
                </div>
              </div>
              <h3 className="font-display font-bold text-xl mb-3">İhtiyacınızı Belirtin</h3>
              <p className="text-muted-foreground">Ne tür bir hizmete ihtiyacınız olduğunu ve detaylarını bize kısaca anlatın.</p>
            </div>
            
            <div className="flex flex-col items-center text-center">
              <div className="w-20 h-20 bg-white rounded-2xl shadow-xl flex items-center justify-center text-primary font-display font-bold text-3xl mb-6 relative">
                2
                <div className="absolute -right-4 top-1/2 -translate-y-1/2 hidden md:block text-border">
                  <ArrowRight className="w-8 h-8" />
                </div>
              </div>
              <h3 className="font-display font-bold text-xl mb-3">Ustalar Teklif Versin</h3>
              <p className="text-muted-foreground">İşinize uygun bölgenizdeki en iyi ustalarımız size hızlıca ulaşsın.</p>
            </div>

            <div className="flex flex-col items-center text-center">
              <div className="w-20 h-20 bg-primary text-white rounded-2xl shadow-xl shadow-primary/30 flex items-center justify-center font-display font-bold text-3xl mb-6">
                3
              </div>
              <h3 className="font-display font-bold text-xl mb-3">İşiniz Hallolsun</h3>
              <p className="text-muted-foreground">Anlaştığınız usta gelsin, işinizi güvenle ve tam zamanında halletsin.</p>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  )
}
