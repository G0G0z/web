import { Layout } from "@/components/layout/Layout"

export default function NotFound() {
  return (
    <Layout>
      <div className="container mx-auto px-4 py-24 flex flex-col items-center justify-center text-center">
        <div className="w-24 h-24 bg-primary/10 text-primary rounded-full flex items-center justify-center mb-8">
          <span className="font-display text-4xl font-bold">404</span>
        </div>
        <h1 className="text-3xl font-display font-bold text-foreground mb-4">Sayfa Bulunamadı</h1>
        <p className="text-muted-foreground max-w-md mb-8">
          Aradığınız sayfaya ulaşılamıyor. Belki taşınmış veya silinmiş olabilir.
        </p>
        <a 
          href="/" 
          className="inline-flex h-11 items-center justify-center rounded-xl bg-primary px-8 text-sm font-medium text-primary-foreground shadow transition-colors hover:bg-primary/90"
        >
          Ana Sayfaya Dön
        </a>
      </div>
    </Layout>
  )
}
