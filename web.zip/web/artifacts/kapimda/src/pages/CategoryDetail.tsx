import { Layout } from "@/components/layout/Layout"
import { useGetCategory, useListCategoryProviders } from "@workspace/api-client-react"
import { useParams, Link } from "wouter"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, ShieldCheck, MapPin, ArrowRight, User, Loader2 } from "lucide-react"
import { getCategoryIcon } from "@/lib/categoryIcons"
import { ProviderAvatar } from "@/components/ProviderAvatar"

export default function CategoryDetail() {
  const params = useParams()
  const slug = params.slug || ""
  
  const { data: category, isLoading: isLoadingCategory } = useGetCategory(slug)
  const { data: providers, isLoading: isLoadingProviders } = useListCategoryProviders(slug)

  if (isLoadingCategory) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="w-10 h-10 animate-spin text-primary" />
        </div>
      </Layout>
    )
  }

  if (!category) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-24 text-center">
          <h1 className="text-3xl font-display font-bold mb-4">Kategori Bulunamadı</h1>
          <p className="text-muted-foreground mb-8">Aradığınız hizmet kategorisine ulaşılamadı.</p>
          <Link href="/">
            <Button>Ana Sayfaya Dön</Button>
          </Link>
        </div>
      </Layout>
    )
  }

  return (
    <Layout>
      {/* Category Hero */}
      <div className="bg-primary/5 py-16 md:py-24 border-b border-border">
        <div className="container mx-auto px-4 max-w-4xl text-center">
          <div className="w-24 h-24 bg-white rounded-3xl shadow-xl mx-auto flex items-center justify-center text-primary mb-8 rotate-3 hover:rotate-0 transition-transform duration-300 [&_svg]:w-10 [&_svg]:h-10">
            {getCategoryIcon(category.slug)}
          </div>
          <h1 className="font-display text-4xl md:text-5xl font-bold mb-6 text-foreground">
            {category.name} Hizmetleri
          </h1>
          <p className="text-lg text-muted-foreground leading-relaxed mb-10 max-w-2xl mx-auto">
            {category.description || `${category.name} alanında uzman, onaylı ve güvenilir ustalarımızdan anında hizmet alın.`}
          </p>
          <Link href={`/hizmet-al?kategori=${category.slug}`}>
            <Button size="lg" className="h-14 px-8 text-base shadow-lg shadow-primary/20 rounded-2xl">
              Hemen {category.name} Talebi Oluştur
            </Button>
          </Link>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <div className="flex items-center justify-between mb-10">
          <h2 className="text-2xl md:text-3xl font-display font-bold">Önerilen Ustalar</h2>
          <Badge variant="secondary" className="px-4 py-1.5 text-sm font-medium">
            {providers?.length || 0} Usta Bulundu
          </Badge>
        </div>

        {isLoadingProviders ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <Card key={i} className="animate-pulse">
                <div className="h-32 bg-muted" />
                <CardContent className="p-6 relative pt-12">
                  <div className="absolute -top-10 left-6 w-20 h-20 rounded-full bg-muted border-4 border-white" />
                  <div className="space-y-3 mt-4">
                    <div className="h-6 bg-muted rounded w-3/4" />
                    <div className="h-4 bg-muted rounded w-1/2" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : providers && providers.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {providers.map((provider) => (
              <Link key={provider.id} href={`/ustalar/${provider.id}`}>
                <Card className="group h-full flex flex-col hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white border-transparent hover:border-primary/20">
                  <div className="h-24 bg-primary/10 rounded-t-2xl" />
                  <CardContent className="p-6 relative pt-12 flex-1 flex flex-col">
                    <div className="absolute -top-10 left-6">
                      <ProviderAvatar
                        avatarUrl={provider.avatarUrl}
                        businessName={provider.businessName}
                        className="w-20 h-20 rounded-full object-cover border-4 border-white shadow-md bg-white"
                        fallbackClassName="w-20 h-20 rounded-full bg-primary/10 text-primary flex items-center justify-center border-4 border-white shadow-md"
                        textClassName="font-display font-bold text-2xl"
                      />
                      {provider.verified && (
                        <div className="absolute bottom-0 right-0 bg-white rounded-full p-0.5" title="Onaylı Usta">
                          <ShieldCheck className="w-5 h-5 text-primary fill-primary/10" />
                        </div>
                      )}
                    </div>
                    
                    <div className="mb-4">
                      <h3 className="font-display font-bold text-xl leading-tight group-hover:text-primary transition-colors mb-1">{provider.businessName}</h3>
                      <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                        <MapPin className="w-4 h-4" />
                        {provider.district ? `${provider.district}, ` : ''}{provider.city}
                      </div>
                    </div>

                    <div className="flex items-center gap-4 mb-6 mt-auto">
                      <div className="flex items-center gap-1.5 font-medium bg-accent/10 text-accent-foreground px-3 py-1.5 rounded-lg">
                        <Star className="w-4 h-4 fill-accent text-accent" />
                        {provider.rating.toFixed(1)} <span className="text-muted-foreground font-normal">({provider.reviewCount})</span>
                      </div>
                      <div className="text-sm font-medium bg-secondary text-secondary-foreground px-3 py-1.5 rounded-lg">
                        {provider.completedJobs} İş
                      </div>
                    </div>
                    
                    <Button variant="outline" className="w-full group-hover:bg-primary group-hover:text-white transition-colors">
                      Profili İncele
                    </Button>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-24 bg-card rounded-3xl border border-border border-dashed">
            <User className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <h3 className="text-xl font-display font-bold mb-2">Bu kategoride henüz usta yok</h3>
            <p className="text-muted-foreground mb-6">Şu anda bu bölgede veya kategoride kayıtlı usta bulunmuyor.</p>
            <Link href="/hizmet-al">
              <Button>Yine de Talep Oluştur</Button>
            </Link>
          </div>
        )}
      </div>
    </Layout>
  )
}
