import { Layout } from "@/components/layout/Layout"
import { useGetProvider, useListProviderReviews } from "@workspace/api-client-react"
import { useParams, Link } from "wouter"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, ShieldCheck, MapPin, CheckCircle2, Clock, Map, MessageSquare, Loader2 } from "lucide-react"
import { ProviderAvatar } from "@/components/ProviderAvatar"

export default function ProviderDetail() {
  const params = useParams()
  const id = Number(params.id)
  
  const { data: provider, isLoading: isLoadingProvider } = useGetProvider(id)
  const { data: reviews, isLoading: isLoadingReviews } = useListProviderReviews(id)

  if (isLoadingProvider) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="w-12 h-12 animate-spin text-primary" />
        </div>
      </Layout>
    )
  }

  if (!provider) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-24 text-center">
          <h1 className="text-3xl font-display font-bold mb-4">Usta Bulunamadı</h1>
          <p className="text-muted-foreground mb-8">Aradığınız usta profiline ulaşılamadı.</p>
          <Link href="/ustalar">
            <Button>Ustalara Dön</Button>
          </Link>
        </div>
      </Layout>
    )
  }

  return (
    <Layout>
      {/* Profile Header */}
      <div className="bg-card border-b border-border">
        <div className="container mx-auto px-4 py-8 lg:py-12">
          <div className="flex flex-col lg:flex-row gap-8 items-start lg:items-center justify-between">
            <div className="flex flex-col sm:flex-row gap-6 items-start sm:items-center">
              <div className="relative">
                <ProviderAvatar
                  avatarUrl={provider.avatarUrl}
                  businessName={provider.businessName}
                  className="w-32 h-32 rounded-full object-cover border-4 border-background shadow-lg"
                  fallbackClassName="w-32 h-32 rounded-full bg-primary/10 text-primary flex items-center justify-center border-4 border-background shadow-lg"
                  textClassName="font-display font-bold text-4xl"
                />
                {provider.verified && (
                  <div className="absolute bottom-1 right-1 bg-white rounded-full p-1 shadow-md" title="Onaylı Usta Kimliği">
                    <ShieldCheck className="w-8 h-8 text-primary fill-primary/10" />
                  </div>
                )}
              </div>
              
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h1 className="text-3xl font-display font-bold text-foreground">
                    {provider.businessName}
                  </h1>
                </div>
                <div className="flex flex-wrap items-center gap-3 text-sm font-medium text-muted-foreground mb-4">
                  <Badge variant="secondary" className="text-sm px-3 py-1">
                    {provider.categoryName}
                  </Badge>
                  <div className="flex items-center gap-1.5">
                    <MapPin className="w-4 h-4" />
                    {provider.district ? `${provider.district}, ` : ''}{provider.city}
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-6">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center text-accent">
                      <Star className="w-5 h-5 fill-current" />
                    </div>
                    <div>
                      <div className="font-bold text-foreground">{provider.rating.toFixed(1)}</div>
                      <div className="text-xs text-muted-foreground">{provider.reviewCount} Değerlendirme</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                      <CheckCircle2 className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="font-bold text-foreground">{provider.completedJobs}</div>
                      <div className="text-xs text-muted-foreground">Tamamlanan İş</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center text-secondary-foreground">
                      <Clock className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="font-bold text-foreground">{provider.yearsExperience} Yıl</div>
                      <div className="text-xs text-muted-foreground">Tecrübe</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="w-full lg:w-auto shrink-0 bg-background p-6 rounded-3xl border border-border/50 shadow-sm text-center lg:text-left">
              <div className="text-sm font-medium text-muted-foreground mb-1">Başlangıç Fiyatı</div>
              <div className="text-3xl font-display font-bold text-primary mb-4">
                ₺{provider.startingPrice} <span className="text-base text-muted-foreground font-normal">/ iş</span>
              </div>
              <Link href={`/hizmet-al?kategori=${provider.categorySlug}`}>
                <Button size="lg" className="w-full shadow-md shadow-primary/20 rounded-2xl h-14 text-base px-8">
                  Hizmet Talebi Oluştur
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          <div className="lg:col-span-2 space-y-8">
            <section>
              <h2 className="text-2xl font-display font-bold mb-4">Hakkında</h2>
              <div className="bg-card rounded-3xl p-8 border border-border/50 shadow-sm">
                <p className="text-muted-foreground leading-relaxed whitespace-pre-line text-lg">
                  {provider.bio || "Usta henüz bir açıklama eklememiş. Detaylı bilgi için hizmet talebi oluşturarak usta ile iletişime geçebilirsiniz."}
                </p>
              </div>
            </section>

            <section>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-display font-bold">Müşteri Yorumları</h2>
                <Badge variant="secondary" className="px-3 py-1 text-sm">
                  {provider.reviewCount} Yorum
                </Badge>
              </div>
              
              {isLoadingReviews ? (
                <div className="space-y-4">
                  {[1, 2, 3].map(i => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="p-6">
                        <div className="flex gap-4 items-start">
                          <div className="w-12 h-12 rounded-full bg-muted" />
                          <div className="space-y-3 flex-1">
                            <div className="h-4 bg-muted rounded w-32" />
                            <div className="h-3 bg-muted rounded w-24" />
                            <div className="h-16 bg-muted rounded w-full mt-4" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : reviews && reviews.length > 0 ? (
                <div className="space-y-6">
                  {reviews.map((review) => (
                    <Card key={review.id} className="border-border/50 shadow-sm">
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center font-bold text-lg text-secondary-foreground shrink-0">
                            {review.customerName.charAt(0)}
                          </div>
                          <div className="flex-1">
                            <div className="flex justify-between items-start mb-1">
                              <h4 className="font-bold">{review.customerName}</h4>
                              <div className="flex items-center gap-0.5">
                                {[...Array(5)].map((_, i) => (
                                  <Star key={i} className={`w-4 h-4 ${i < review.rating ? "fill-accent text-accent" : "fill-muted text-muted"}`} />
                                ))}
                              </div>
                            </div>
                            <div className="text-xs text-muted-foreground mb-3">
                              {new Date(review.createdAt).toLocaleDateString('tr-TR', { year: 'numeric', month: 'long', day: 'numeric' })}
                            </div>
                            <p className="text-muted-foreground leading-relaxed">
                              {review.comment}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-16 bg-card rounded-3xl border border-border border-dashed">
                  <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                  <p className="text-lg font-medium text-foreground mb-2">Henüz yorum yapılmamış</p>
                  <p className="text-muted-foreground">Bu usta için ilk değerlendirmeyi yapan siz olun.</p>
                </div>
              )}
            </section>
          </div>

          <div className="space-y-6">
            <Card className="border-border/50 shadow-sm">
              <CardContent className="p-6 space-y-6">
                <h3 className="font-display font-bold text-xl border-b border-border pb-4">Hizmet Bölgeleri</h3>
                <div className="flex items-start gap-3">
                  <div className="mt-1 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">
                    <Map className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-medium text-foreground mb-1">Hizmet Verilen İl</div>
                    <div className="text-muted-foreground">{provider.city}</div>
                  </div>
                </div>
                {provider.district && (
                  <div className="flex items-start gap-3">
                    <div className="mt-1 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">
                      <MapPin className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-medium text-foreground mb-1">İlçe / Bölge</div>
                      <div className="text-muted-foreground">{provider.district} ve çevresi</div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="bg-primary text-primary-foreground border-transparent">
              <CardContent className="p-6 text-center">
                <h3 className="font-display font-bold text-xl mb-2">Hemen İletişime Geçin</h3>
                <p className="text-primary-foreground/80 text-sm mb-6">
                  Bu ustadan hizmet almak için talebinizi oluşturun, en kısa sürede size dönüş yapsın.
                </p>
                <Link href={`/hizmet-al?kategori=${provider.categorySlug}`}>
                  <Button variant="secondary" size="lg" className="w-full h-14 rounded-2xl">
                    Talep Oluştur
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  )
}
