import {
  db,
  pool,
  categoriesTable,
  providersTable,
  reviewsTable,
} from "@workspace/db";

type CategorySeed = {
  name: string;
  slug: string;
  icon: string;
  description: string;
};

const categories: CategorySeed[] = [
  { name: "Temizlik", slug: "temizlik", icon: "sparkles", description: "Ev ve ofis temizliği" },
  { name: "Nakliyat", slug: "nakliyat", icon: "truck", description: "Evden eve ve ofis taşımacılığı" },
  { name: "Boya Badana", slug: "boya-badana", icon: "paintbrush", description: "İç ve dış cephe boya işleri" },
  { name: "Elektrikçi", slug: "elektrikci", icon: "zap", description: "Elektrik tesisatı ve arıza giderme" },
  { name: "Tesisatçı", slug: "tesisatci", icon: "wrench", description: "Su tesisatı ve kombi bakımı" },
  { name: "Klima Bakım", slug: "klima-bakim", icon: "wind", description: "Klima montaj, bakım ve gaz dolumu" },
  { name: "Özel Ders", slug: "ozel-ders", icon: "book-open", description: "Birebir özel ders ve eğitim" },
  { name: "Düğün Organizasyonu", slug: "dugun-organizasyonu", icon: "heart", description: "Düğün ve nişan organizasyonu" },
  { name: "Mobilya Montaj", slug: "mobilya-montaj", icon: "hammer", description: "Mobilya kurulum ve montaj hizmeti" },
  { name: "Halı Yıkama", slug: "hali-yikama", icon: "droplets", description: "Halı, koltuk ve perde yıkama" },
  { name: "Koltuk Yıkama", slug: "koltuk-yikama", icon: "armchair", description: "Koltuk, kanepe ve döşeme yıkama" },
  { name: "Cam Silme", slug: "cam-silme", icon: "spray-can", description: "Ev ve iş yeri cam temizliği" },
  { name: "İlaçlama", slug: "ilaclama", icon: "bug", description: "Haşere ve zararlı mücadelesi" },
  { name: "Çilingir", slug: "cilingir", icon: "key-round", description: "Kapı açma, kilit değişimi ve anahtar kopyalama" },
  { name: "Beyaz Eşya Tamiri", slug: "beyaz-esya-tamiri", icon: "refrigerator", description: "Buzdolabı, çamaşır makinesi ve bulaşık makinesi tamiri" },
  { name: "Teknik Servis", slug: "teknik-servis", icon: "laptop", description: "Bilgisayar ve telefon tamiri" },
  { name: "Bahçıvanlık", slug: "bahcivanlik", icon: "trees", description: "Bahçe düzenleme ve peyzaj hizmeti" },
  { name: "Oto Bakım", slug: "oto-bakim", icon: "car-front", description: "Oto yıkama ve detaylı bakım" },
  { name: "Güzellik", slug: "guzellik", icon: "scissors", description: "Kuaför ve güzellik hizmetleri" },
  { name: "Masaj & Spa", slug: "masaj-spa", icon: "flower-2", description: "Evde masaj ve spa hizmeti" },
  { name: "Evcil Hayvan Bakımı", slug: "evcil-hayvan-bakimi", icon: "paw-print", description: "Pet kuaförü ve hayvan bakım hizmeti" },
  { name: "Çocuk Bakımı", slug: "cocuk-bakimi", icon: "baby", description: "Bebek ve çocuk bakıcılığı" },
  { name: "Fotoğrafçılık", slug: "fotografcilik", icon: "camera", description: "Etkinlik ve stüdyo fotoğrafçılığı" },
  { name: "Muhasebe", slug: "muhasebe", icon: "calculator", description: "Mali müşavirlik ve muhasebe danışmanlığı" },
  { name: "Marangoz", slug: "marangoz", icon: "ruler", description: "Ahşap işleri ve özel mobilya üretimi" },
  { name: "Web & Yazılım", slug: "web-yazilim", icon: "code", description: "Web sitesi ve yazılım geliştirme hizmeti" },
];

type ProviderSeed = {
  categorySlug: string;
  name: string;
  businessName: string;
  city: string;
  district: string;
  rating: string;
  reviewCount: number;
  completedJobs: number;
  bio: string;
  verified: boolean;
  yearsExperience: number;
  startingPrice: number;
  avatarUrl: string;
  reviews: { customerName: string; rating: number; comment: string }[];
};

const providers: ProviderSeed[] = [
  {
    categorySlug: "temizlik",
    name: "Ayşe Kaya",
    businessName: "Ev ve Ofis Temizlik Hizmetleri",
    city: "İstanbul",
    district: "Kadıköy",
    rating: "4.9",
    reviewCount: 128,
    completedJobs: 340,
    bio: "Ev ve ofislerde derinlemesine temizlik, cam silme ve genel düzen hizmeti sunulur. Deneyimli ekiplerle hijyenik ve güvenilir temizlik sağlanır.",
    verified: true,
    yearsExperience: 10,
    startingPrice: 450,
    avatarUrl: "https://media.gettyimages.com/id/1328654112/photo/young-female-housekeeping-using-foam-cleaner-cleaning-house-living-room-and-sofa-surface.jpg?s=612x612&w=0&k=20&c=DgajQa3TGRmZQ39C_LiDrXfi_w84J4G6aDZKRK8R1og=",
    reviews: [
      { customerName: "Merve T.", rating: 5, comment: "Çok titiz ve zamanında geldi, kesinlikle tavsiye ederim." },
      { customerName: "Okan D.", rating: 5, comment: "Evim hiç bu kadar temiz olmamıştı, teşekkürler." },
      { customerName: "Zübeyde K.", rating: 5, comment: "Fayans aralarına kadar temizlediler, çok memnun kaldım." },
      { customerName: "Rüstem A.", rating: 4, comment: "Randevu saatine tam uydular, işleri de düzgündü." },
      { customerName: "Filiz N.", rating: 5, comment: "Taşınma öncesi temizlik için çağırdım, kusursuz teslim ettiler." },
    ],
  },
  {
    categorySlug: "temizlik",
    name: "Fatma Yıldız",
    businessName: "Haftalık Temizlik Hizmetleri",
    city: "Ankara",
    district: "Çankaya",
    rating: "4.7",
    reviewCount: 76,
    completedJobs: 190,
    bio: "Haftalık ve aylık düzenli temizlik paketleriyle ev ve iş yerlerinde sürekli temizlik hizmeti sağlanır.",
    verified: true,
    yearsExperience: 6,
    startingPrice: 400,
    avatarUrl: "https://media.gettyimages.com/id/1137136160/photo/young-woman-tired-of-spring-cleaning-house.jpg?s=612x612&w=0&k=20&c=UFQnfph1oYE8ZeGUgO1OCcYAn1UAb_pXMolF2X7vL2o=",
    reviews: [
      { customerName: "Kerem A.", rating: 4, comment: "İşini iyi yapıyor, düzenli olarak çağırıyorum." },
      { customerName: "Songül T.", rating: 5, comment: "Haftalık paket aldık, her seferinde aynı özenle geliyorlar." },
      { customerName: "Barış E.", rating: 4, comment: "Fiyat performans olarak gayet makul buldum." },
    ],
  },
  {
    categorySlug: "nakliyat",
    name: "Mehmet Demir",
    businessName: "Evden Eve Nakliyat Hizmetleri",
    city: "İstanbul",
    district: "Ümraniye",
    rating: "4.8",
    reviewCount: 214,
    completedJobs: 510,
    bio: "Evden eve nakliyat, asansörlü taşıma ve eşya paketleme hizmetleri güvenli ve sigortalı şekilde sunulur.",
    verified: true,
    yearsExperience: 12,
    startingPrice: 2500,
    avatarUrl: "https://thumbs.dreamstime.com/b/male-movers-unloading-cardboard-boxes-form-truck-overhead-view-street-182284282.jpg",
    reviews: [
      { customerName: "Selin K.", rating: 5, comment: "Eşyalarımıza çok dikkatli davrandılar, hiçbir hasar olmadı." },
      { customerName: "Burak Ş.", rating: 5, comment: "Zamanında geldiler, hızlı ve profesyonel bir taşıma yaptılar." },
      { customerName: "Aylin G.", rating: 5, comment: "Paketleme malzemesini de kendileri getirdi, çok pratik oldu." },
      { customerName: "Metin U.", rating: 4, comment: "Asansörlü taşıma sayesinde hiç yorulmadık, teşekkürler." },
    ],
  },
  {
    categorySlug: "nakliyat",
    name: "Hakan Şahin",
    businessName: "Şehir İçi ve Şehirler Arası Nakliyat",
    city: "İzmir",
    district: "Bornova",
    rating: "4.6",
    reviewCount: 58,
    completedJobs: 150,
    bio: "Şehir içi ve şehirler arası taşımacılık, uygun fiyatlı ve güvenilir hizmet anlayışıyla gerçekleştirilir.",
    verified: false,
    yearsExperience: 8,
    startingPrice: 2200,
    avatarUrl: "https://thumbs.dreamstime.com/b/two-young-male-movers-loading-cardboard-boxes-furniture-moving-truck-street-male-movers-loading-cardboard-boxes-182283895.jpg",
    reviews: [
      { customerName: "Deniz Y.", rating: 4, comment: "Fiyat performans açısından gayet iyi." },
      { customerName: "Pınar C.", rating: 5, comment: "Şehirler arası taşımada hiç sorun yaşamadık, çok güvenilirler." },
    ],
  },
  {
    categorySlug: "boya-badana",
    name: "Ali Vural",
    businessName: "Boya ve Dekorasyon Hizmetleri",
    city: "İstanbul",
    district: "Beşiktaş",
    rating: "4.9",
    reviewCount: 95,
    completedJobs: 260,
    bio: "İç cephe boya, dekoratif duvar kaplama ve alçıpan uygulamaları profesyonel ekiplerle yapılır.",
    verified: true,
    yearsExperience: 15,
    startingPrice: 300,
    avatarUrl: "https://media.gettyimages.com/id/1286585958/photo/low-angle-of-two-hand-catching-a-paint-roller-full-of-grey-painting-on-a-grey-wall-the.jpg?s=612x612&w=0&k=20&c=Wj5yzcVpbR00vh_CLAL8T6uSkMqU-zZVS3f7WqyP7ao=",
    reviews: [
      { customerName: "Ece M.", rating: 5, comment: "Detaylara çok dikkat etti, sonuç mükemmel oldu." },
      { customerName: "Kaya D.", rating: 5, comment: "Salonumuzu dekoratif boyayla yeniledi, çok beğendik." },
      { customerName: "Sema Y.", rating: 4, comment: "İşi zamanında bitirdi, ortalığı da temiz bıraktı." },
    ],
  },
  {
    categorySlug: "elektrikci",
    name: "Serkan Aydın",
    businessName: "Elektrik Tamir ve Tesisat Hizmetleri",
    city: "İstanbul",
    district: "Maltepe",
    rating: "4.8",
    reviewCount: 143,
    completedJobs: 400,
    bio: "7/24 elektrik arıza giderme, tesisat yenileme ve aydınlatma çözümleri sunulmaktadır.",
    verified: true,
    yearsExperience: 11,
    startingPrice: 350,
    avatarUrl: "https://media.gettyimages.com/id/1463475388/photo/male-electrician-working-and-install-wire-at-construction-site.jpg?s=612x612&w=0&k=20&c=9EC9X-PI9HHmPW-OwGZ-v_a9wFZcjxbYUsn4xQfzY20=",
    reviews: [
      { customerName: "Tolga B.", rating: 5, comment: "Gece yarısı arızaya hemen geldi, çok teşekkür ederim." },
      { customerName: "Yeliz K.", rating: 5, comment: "Priz arızasını dakikalar içinde çözdü, çok bilgiliydi." },
      { customerName: "Hasan F.", rating: 4, comment: "Aydınlatma projemizi baştan sona güzelce kurdu." },
    ],
  },
  {
    categorySlug: "tesisatci",
    name: "Murat Öztürk",
    businessName: "Su Tesisatı ve Kombi Bakım Hizmetleri",
    city: "Bursa",
    district: "Nilüfer",
    rating: "4.7",
    reviewCount: 87,
    completedJobs: 230,
    bio: "Su kaçağı tespiti, kombi bakımı ve banyo/mutfak tesisatı yenileme hizmetleri verilmektedir.",
    verified: true,
    yearsExperience: 9,
    startingPrice: 380,
    avatarUrl: "https://thumbs.dreamstime.com/b/plumber-fixing-under-sink-kitchen-47014889.jpg",
    reviews: [
      { customerName: "Gizem P.", rating: 4, comment: "Su kaçağını hızlıca buldu ve çözdü." },
      { customerName: "Mert S.", rating: 5, comment: "Kombi bakımını çok titiz yaptı, ısınma sorunumuz bitti." },
    ],
  },
  {
    categorySlug: "klima-bakim",
    name: "Emre Koç",
    businessName: "Klima Montaj ve Bakım Servisi",
    city: "İstanbul",
    district: "Şişli",
    rating: "4.9",
    reviewCount: 112,
    completedJobs: 300,
    bio: "Klima montajı, periyodik bakım ve gaz dolumu hizmetleri uzman teknisyenlerce gerçekleştirilir.",
    verified: true,
    yearsExperience: 10,
    startingPrice: 500,
    avatarUrl: "https://media.gettyimages.com/id/2211719481/photo/technician-with-screwdriver-repairing-air-conditioner-at-home.jpg?s=612x612&w=0&k=20&c=21FxuUgmwMwNgxh0LUK9GrrBV8cnoWhZZ_9FAGq2_tw=",
    reviews: [
      { customerName: "Aslı N.", rating: 5, comment: "Çok hızlı ve düzgün bir montaj yaptı." },
      { customerName: "Utku R.", rating: 5, comment: "Gaz dolumundan sonra klima eskisinden çok daha iyi soğutuyor." },
      { customerName: "Ceyda M.", rating: 4, comment: "Randevuya sadık kaldı, montajı özenle tamamladı." },
    ],
  },
  {
    categorySlug: "ozel-ders",
    name: "Zeynep Arslan",
    businessName: "Matematik Koçluğu",
    city: "Ankara",
    district: "Yenimahalle",
    rating: "5.0",
    reviewCount: 64,
    completedJobs: 180,
    bio: "Ortaokul ve lise seviyesinde matematik ve fen bilimleri derslerinde birebir özel ders desteği sağlanır. Konu eksiklerini kapatmaya ve sınav başarısını artırmaya odaklanılır.",
    verified: true,
    yearsExperience: 7,
    startingPrice: 250,
    avatarUrl: "https://media.gettyimages.com/id/1012230604/photo/teacher-helps-high-school-student-with-a-math-problem-on-the-whiteboard.jpg?s=612x612&w=0&k=20&c=4Chi6LmmtOuQ8Wmf5QaRlstcRo6k6BciI4iQifQJHiQ=",
    reviews: [
      { customerName: "Cem Y.", rating: 5, comment: "Oğlumun notları kısa sürede çok yükseldi." },
      { customerName: "Burcu İ.", rating: 5, comment: "Kızım artık matematikten korkmuyor, anlatımı çok sabırlı." },
      { customerName: "Tuncay O.", rating: 5, comment: "Sınav öncesi eksikleri hızlıca kapattı, teşekkürler." },
    ],
  },
  {
    categorySlug: "dugun-organizasyonu",
    name: "Elif Çelik",
    businessName: "Düğün ve Organizasyon Hizmetleri",
    city: "İstanbul",
    district: "Sarıyer",
    rating: "4.9",
    reviewCount: 51,
    completedJobs: 90,
    bio: "Düğün, nişan ve kına organizasyonlarında mekan, dekorasyon ve planlama dahil uçtan uca hizmet sunulur.",
    verified: true,
    yearsExperience: 8,
    startingPrice: 15000,
    avatarUrl: "https://www.brides.com/thmb/4dEvkCG01PHn40g-WTqKJvoQah4=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/29-groom-yellow-suit-mexico-wedding-reception-table-decor-jeremy-chou-0524-017e604576a74421bf642dc3ec5de370.jpg",
    reviews: [
      { customerName: "Buse ve Kaan", rating: 5, comment: "Hayalimizdeki düğünü gerçekleştirdiler, çok teşekkürler." },
      { customerName: "Gül ve Emre", rating: 5, comment: "Dekorasyon ve organizasyonu kusursuzdu, misafirlerimiz bayıldı." },
    ],
  },
  {
    categorySlug: "mobilya-montaj",
    name: "Onur Kılıç",
    businessName: "Mobilya Montaj Hizmetleri",
    city: "İzmir",
    district: "Karşıyaka",
    rating: "4.6",
    reviewCount: 39,
    completedJobs: 140,
    bio: "Gardırop, mutfak dolabı ve ofis mobilyası montajı hızlı ve özenli şekilde yapılır.",
    verified: false,
    yearsExperience: 5,
    startingPrice: 200,
    avatarUrl: "https://cdn.shopify.com/s/files/1/0640/1409/0461/files/1830b8749f72da69e369dafc7e9d8651022fb482_5066ef89-e96a-4190-940e-3bf73bbd60c1.jpg",
    reviews: [
      { customerName: "Pelin S.", rating: 4, comment: "Hızlı ve temiz bir montaj yaptı." },
      { customerName: "Kubilay H.", rating: 5, comment: "Gardırobu tek başına ve titizlikle kurdu." },
    ],
  },
  {
    categorySlug: "hali-yikama",
    name: "Baran Aksoy",
    businessName: "Halı Yıkama Hizmetleri",
    city: "İstanbul",
    district: "Bakırköy",
    rating: "4.8",
    reviewCount: 102,
    completedJobs: 420,
    bio: "Halı ve perde yıkamada aynı gün teslim imkanıyla hijyenik temizlik sağlanır.",
    verified: true,
    yearsExperience: 9,
    startingPrice: 150,
    avatarUrl: "https://media.istockphoto.com/id/181887439/photo/steam-cleaning-carpets.jpg?s=612x612&w=0&k=20&c=2mfLTPR9BntMQybigK18bXPW18kfb7Uiymr3dq17eHc=",
    reviews: [
      { customerName: "Nazlı E.", rating: 5, comment: "Halılarımız yeni gibi oldu, çok memnun kaldım." },
      { customerName: "Onur Ç.", rating: 5, comment: "Aynı gün teslim ettiler, kokusu bile çok hoştu." },
      { customerName: "Duygu Z.", rating: 4, comment: "Lekeler tamamen çıktı, fiyatı da uygundu." },
    ],
  },
  {
    categorySlug: "koltuk-yikama",
    name: "Serdar Yılmaz",
    businessName: "Koltuk ve Döşeme Yıkama Hizmetleri",
    city: "İstanbul",
    district: "Ataşehir",
    rating: "4.7",
    reviewCount: 68,
    completedJobs: 210,
    bio: "Koltuk, kanepe ve sandalye yıkamada buharlı sistemle hijyenik temizlik sağlanır.",
    verified: true,
    yearsExperience: 7,
    startingPrice: 200,
    avatarUrl: "https://pristinegreencleaning.com/storage/blog/uploads/Steam-Cleaner-vs.-Upholstery-Cleaner-Which-One-Do-You-Need-64bb78f9ce02b.jpeg",
    reviews: [
      { customerName: "İrem K.", rating: 5, comment: "Koltuklarımız kısa sürede kurudu ve kokusu çok güzeldi." },
      { customerName: "Salih B.", rating: 4, comment: "Buharlı yıkama sayesinde lekeler tamamen gitti." },
    ],
  },
  {
    categorySlug: "cam-silme",
    name: "Yusuf Er",
    businessName: "Cam ve Cephe Temizlik Hizmetleri",
    city: "İzmir",
    district: "Konak",
    rating: "4.6",
    reviewCount: 45,
    completedJobs: 175,
    bio: "Apartman, villa ve iş yerlerinde profesyonel cam ve cephe temizliği yapılmaktadır.",
    verified: true,
    yearsExperience: 6,
    startingPrice: 180,
    avatarUrl: "https://media.gettyimages.com/id/1397861289/photo/cleaning-windows-on-a-residential-building.jpg?s=612x612&w=0&k=20&c=-r2vmkJU8aZsWjYnnDg7FQHw9UMpQbdbMH9uiQ-CFtA=",
    reviews: [
      { customerName: "Hande T.", rating: 4, comment: "Camlar pırıl pırıl oldu, teşekkürler." },
      { customerName: "Erhan K.", rating: 5, comment: "Cephe camlarını bile eksiksiz temizlediler, çok memnunum." },
    ],
  },
  {
    categorySlug: "ilaclama",
    name: "Cengiz Polat",
    businessName: "İlaçlama ve Haşere Mücadelesi Hizmetleri",
    city: "Ankara",
    district: "Keçiören",
    rating: "4.8",
    reviewCount: 91,
    completedJobs: 260,
    bio: "Böcek, haşere ve kemirgen mücadelesinde ruhsatlı ve güvenli ilaçlama uygulamaları yapılır.",
    verified: true,
    yearsExperience: 12,
    startingPrice: 350,
    avatarUrl: "https://media.gettyimages.com/id/1222524543/photo/oneman-in-protective-suit-spraying-the-house-and-disinfecting-the-housing-exterminator-pest.jpg?s=612x612&w=0&k=20&c=NaT2qRx_rwrsZDwh-qCMF5imt90Bsnsp2lTLSC1CABw=",
    reviews: [
      { customerName: "Sibel A.", rating: 5, comment: "Bir daha hiç böcek görmedik, çok etkili oldu." },
      { customerName: "Fikret Y.", rating: 5, comment: "Uygulama sonrası koku kalmadı, çocuklar için de güvenliydi." },
      { customerName: "Nesrin D.", rating: 4, comment: "Randevuya zamanında geldiler, işlem hızlı bitti." },
    ],
  },
  {
    categorySlug: "cilingir",
    name: "Tarık Bulut",
    businessName: "7/24 Çilingir Hizmetleri",
    city: "İstanbul",
    district: "Beyoğlu",
    rating: "4.9",
    reviewCount: 156,
    completedJobs: 480,
    bio: "Kapı açma, kilit değişimi ve oto anahtar kopyalama hizmetleri günün her saati sunulmaktadır.",
    verified: true,
    yearsExperience: 14,
    startingPrice: 250,
    avatarUrl: "https://thumbs.dreamstime.com/b/closeup-hands-locksmith-using-metal-pick-tools-to-open-locked-door-76922901.jpg",
    reviews: [
      { customerName: "Volkan D.", rating: 5, comment: "Gece yarısı kapıda kaldık, 15 dakikada geldi." },
      { customerName: "Ayten S.", rating: 5, comment: "Kilidi kapıya zarar vermeden açtı, çok ustaydı." },
      { customerName: "Bora K.", rating: 5, comment: "Oto anahtarımı kopyaladı, gayet uygun fiyatlıydı." },
    ],
  },
  {
    categorySlug: "beyaz-esya-tamiri",
    name: "İsmail Güneş",
    businessName: "Beyaz Eşya Tamir Servisi",
    city: "Bursa",
    district: "Osmangazi",
    rating: "4.7",
    reviewCount: 73,
    completedJobs: 220,
    bio: "Çamaşır makinesi, buzdolabı ve bulaşık makinesi arıza tespiti ve onarımı garantili şekilde yapılır.",
    verified: true,
    yearsExperience: 10,
    startingPrice: 300,
    avatarUrl: "https://images.pexels.com/photos/32588545/pexels-photo-32588545/free-photo-of-technician-repairing-appliance-in-workshop.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
    reviews: [
      { customerName: "Fahri C.", rating: 4, comment: "Parça değişimi hızlı ve garantili oldu." },
      { customerName: "Melike U.", rating: 5, comment: "Buzdolabımızı aynı gün tamir etti, çok teşekkür ederiz." },
    ],
  },
  {
    categorySlug: "teknik-servis",
    name: "Kaan Yalçın",
    businessName: "Bilgisayar ve Telefon Teknik Servisi",
    city: "İstanbul",
    district: "Bahçelievler",
    rating: "4.8",
    reviewCount: 84,
    completedJobs: 240,
    bio: "Bilgisayar, laptop ve telefon tamiri, format atma ve veri kurtarma hizmetleri sunulmaktadır.",
    verified: true,
    yearsExperience: 8,
    startingPrice: 200,
    avatarUrl: "https://images.pexels.com/photos/33531806/pexels-photo-33531806/free-photo-of-technician-repairing-laptop-in-workshop.jpeg?cs=tinysrgb&dpr=1&w=500",
    reviews: [
      { customerName: "Damla Y.", rating: 5, comment: "Bilgisayarımı aynı gün teslim etti, çok memnunum." },
      { customerName: "Serhat A.", rating: 5, comment: "Verilerimi kurtardı, gerçekten profesyonel bir servis." },
    ],
  },
  {
    categorySlug: "bahcivanlik",
    name: "Rıza Aktaş",
    businessName: "Bahçe Düzenleme ve Peyzaj Hizmetleri",
    city: "Antalya",
    district: "Muratpaşa",
    rating: "4.7",
    reviewCount: 52,
    completedJobs: 160,
    bio: "Bahçe düzenleme, çim bakımı ve budama işleri deneyimli ekiplerle gerçekleştirilir.",
    verified: true,
    yearsExperience: 11,
    startingPrice: 400,
    avatarUrl: "https://media.gettyimages.com/id/2207150736/photo/professional-gardener-trimming-hedge.jpg?s=612x612&w=0&k=20&c=SYxqzDJ5z4916O4ndr20UQQiA1LX8sTRdBAIPumQ0oE=",
    reviews: [
      { customerName: "Aylin B.", rating: 5, comment: "Bahçemiz baştan yaratıldı, çok beğendik." },
      { customerName: "Kemal T.", rating: 4, comment: "Çim bakımını düzenli yapıyorlar, bahçe her zaman canlı." },
    ],
  },
  {
    categorySlug: "oto-bakim",
    name: "Barış Kurt",
    businessName: "Oto Yıkama ve Bakım Hizmetleri",
    city: "İstanbul",
    district: "Pendik",
    rating: "4.6",
    reviewCount: 61,
    completedJobs: 310,
    bio: "Detaylı oto yıkama, iç temizlik ve seramik kaplama hizmetleri sunulmaktadır.",
    verified: false,
    yearsExperience: 6,
    startingPrice: 250,
    avatarUrl: "https://thumbs.dreamstime.com/b/man-washing-car-self-service-wash-high-pressure-vehicle-washer-machine-sprays-foam-mlada-boleslav-166617604.jpg",
    reviews: [
      { customerName: "Emirhan T.", rating: 4, comment: "Araç yeni gibi oldu, fiyatı da uygundu." },
      { customerName: "Sinem R.", rating: 5, comment: "Seramik kaplama sonrası araç pırıl pırıl parlıyor." },
    ],
  },
  {
    categorySlug: "guzellik",
    name: "Selin Uçar",
    businessName: "Evde Güzellik ve Bakım Hizmetleri",
    city: "İstanbul",
    district: "Beşiktaş",
    rating: "4.9",
    reviewCount: 118,
    completedJobs: 350,
    bio: "Evde saç, cilt bakımı ve makyaj hizmetleri profesyonel güzellik uzmanlarınca sağlanır.",
    verified: true,
    yearsExperience: 9,
    startingPrice: 300,
    avatarUrl: "https://media.gettyimages.com/id/1349298950/photo/close-up-of-unrecognizable-hairdresser-cutting-a-female-customer%C3%A2s-hair.jpg?s=612x612&w=0&k=20&c=s-FpOPuIcR5ULS7pKldF2AMNgmD2-sq_wzsTzqPUoxM=",
    reviews: [
      { customerName: "Gamze R.", rating: 5, comment: "Evime geldi, çok profesyonel ve titizdi." },
      { customerName: "Elvan S.", rating: 5, comment: "Saç bakımım harika oldu, ürünleri de kaliteliydi." },
      { customerName: "Neslihan T.", rating: 4, comment: "Zamanında geldi, işini gayet iyi yapıyor." },
    ],
  },
  {
    categorySlug: "masaj-spa",
    name: "Nihan Demirtaş",
    businessName: "Evde Masaj ve Spa Hizmetleri",
    city: "İzmir",
    district: "Karşıyaka",
    rating: "4.8",
    reviewCount: 47,
    completedJobs: 130,
    bio: "Evde İsveç masajı, aromaterapi ve spa bakımı hizmetleri sunulmaktadır.",
    verified: true,
    yearsExperience: 5,
    startingPrice: 450,
    avatarUrl: "https://media.gettyimages.com/id/1051690592/photo/senior-woman-having-head-massage-by-unrecognizable-therapist-at-the-spa.jpg?s=612x612&w=0&k=20&c=j3yoL4YF0SDgDsxpfyHNgZ9pb3cpyLy7DI-28zQWWbA=",
    reviews: [
      { customerName: "Ozan F.", rating: 5, comment: "Çok rahatlatıcıydı, kesinlikle tekrar çağıracağım." },
      { customerName: "Beril N.", rating: 5, comment: "Aromaterapi seansı gerçekten stres attırdı, çok iyiydi." },
    ],
  },
  {
    categorySlug: "evcil-hayvan-bakimi",
    name: "Ebru Sönmez",
    businessName: "Pet Kuaförü ve Hayvan Bakım Hizmetleri",
    city: "Ankara",
    district: "Çankaya",
    rating: "4.9",
    reviewCount: 88,
    completedJobs: 270,
    bio: "Kedi ve köpekler için tıraş, tırnak kesimi ve genel bakım hizmetleri verilmektedir.",
    verified: true,
    yearsExperience: 7,
    startingPrice: 220,
    avatarUrl: "https://images.pexels.com/photos/6131568/pexels-photo-6131568.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
    reviews: [
      { customerName: "Naz K.", rating: 5, comment: "Köpeğim çok mutlu döndü, ellerine sağlık." },
      { customerName: "Alper D.", rating: 5, comment: "Kedimiz çok huysuzdur ama ona sabırla davrandılar." },
    ],
  },
  {
    categorySlug: "cocuk-bakimi",
    name: "Derya Aydemir",
    businessName: "Bebek ve Çocuk Bakım Hizmetleri",
    city: "İstanbul",
    district: "Kadıköy",
    rating: "5.0",
    reviewCount: 34,
    completedJobs: 95,
    bio: "Sertifikalı ve referanslı bebek/çocuk bakıcılığı hizmeti sunulmaktadır.",
    verified: true,
    yearsExperience: 8,
    startingPrice: 400,
    avatarUrl: "https://media.gettyimages.com/id/1436262040/photo/childcare-worker-with-babies.jpg?s=612x612&w=0&k=20&c=iDzsrFIIxzOaUkuWL9JX_dHrgMs9Pv1gWMZLyOCLps8=",
    reviews: [
      { customerName: "Yasemin O.", rating: 5, comment: "Çocuğumuza çok iyi baktı, güvenle bırakabiliyoruz." },
      { customerName: "Tolunay E.", rating: 5, comment: "Referansları gerçekten doğruydu, çok güvenilir bir hizmet." },
    ],
  },
  {
    categorySlug: "fotografcilik",
    name: "Cem Aksu",
    businessName: "Etkinlik ve Stüdyo Fotoğrafçılığı",
    city: "İstanbul",
    district: "Şişli",
    rating: "4.9",
    reviewCount: 56,
    completedJobs: 140,
    bio: "Düğün, doğum günü ve kurumsal etkinliklerde profesyonel fotoğraf ve video çekim hizmeti sağlanır.",
    verified: true,
    yearsExperience: 10,
    startingPrice: 2000,
    avatarUrl: "https://upload.wikimedia.org/wikipedia/commons/4/49/A_Kent_Wedding_Videographer_Filming_In_Canterbury_Cathedral_Crypt_.jpg",
    reviews: [
      { customerName: "Beste M.", rating: 5, comment: "Fotoğraflarımız harika çıktı, çok yaratıcı bir gözü var." },
      { customerName: "Caner P.", rating: 5, comment: "Düğün videomuzu sinema kalitesinde hazırladılar." },
    ],
  },
  {
    categorySlug: "muhasebe",
    name: "Hüseyin Taş",
    businessName: "Mali Müşavirlik ve Muhasebe Hizmetleri",
    city: "Ankara",
    district: "Çankaya",
    rating: "4.7",
    reviewCount: 42,
    completedJobs: 110,
    bio: "KOBİ ve şahıs şirketleri için muhasebe, vergi ve SGK danışmanlığı hizmeti sunulmaktadır.",
    verified: true,
    yearsExperience: 15,
    startingPrice: 500,
    avatarUrl: "https://thumbs.dreamstime.com/b/white-calculator-pen-documents-lying-accountant-s-desk-businesswoman-wearing-blue-dress-working-background-444596031.jpg",
    reviews: [
      { customerName: "Orhan Ş.", rating: 5, comment: "İşlerimizi düzenli ve zamanında takip ediyor." },
      { customerName: "Gonca V.", rating: 4, comment: "Vergi beyannamelerimizi hiç aksatmadan hazırlıyorlar." },
    ],
  },
  {
    categorySlug: "marangoz",
    name: "Nurettin Işık",
    businessName: "Marangozluk ve Ahşap İşleri",
    city: "Bursa",
    district: "Yıldırım",
    rating: "4.8",
    reviewCount: 39,
    completedJobs: 105,
    bio: "Özel ölçü mobilya, ahşap kapı ve dekorasyon işleri usta marangozlarca üretilir.",
    verified: true,
    yearsExperience: 18,
    startingPrice: 600,
    avatarUrl: "https://media.gettyimages.com/id/1480894682/photo/woodworking-workshop-and-carpenter-with-frame-for-furniture-production-manufacturing-and.jpg?s=612x612&w=0&k=20&c=N7JSRXXODD59R2TMTDjXJ0IfF98Ma0PHVU1Fz8M08uc=",
    reviews: [
      { customerName: "Ceren V.", rating: 5, comment: "İstediğimiz tasarımı birebir yaptı, çok kaliteli." },
      { customerName: "Tayfun B.", rating: 5, comment: "Ahşap işçiliği gerçekten usta elinden çıkma gibi." },
    ],
  },
  {
    categorySlug: "web-yazilim",
    name: "Efe Korkmaz",
    businessName: "Web ve Yazılım Geliştirme Hizmetleri",
    city: "İstanbul",
    district: "Kadıköy",
    rating: "4.9",
    reviewCount: 28,
    completedJobs: 60,
    bio: "Küçük işletmeler için web sitesi, e-ticaret altyapısı ve mobil uygulama geliştirme hizmeti sunulmaktadır.",
    verified: true,
    yearsExperience: 6,
    startingPrice: 3500,
    avatarUrl: "https://images.pexels.com/photos/12899191/pexels-photo-12899191.jpeg?cs=tinysrgb&dpr=1&w=500",
    reviews: [
      { customerName: "Zehra L.", rating: 5, comment: "Sitemizi zamanında ve beklentimizin üstünde teslim etti." },
      { customerName: "Doğukan İ.", rating: 5, comment: "E-ticaret sitemiz için harika bir altyapı kurdu." },
    ],
  },
];

async function seed() {
  console.log("Seeding Kapımda data...");

  // Reseed providers/reviews from scratch to avoid duplicates on repeated runs.
  await db.delete(reviewsTable);
  await db.delete(providersTable);

  const categoryIdBySlug = new Map<string, number>();

  for (const category of categories) {
    const [row] = await db
      .insert(categoriesTable)
      .values(category)
      .onConflictDoUpdate({
        target: categoriesTable.slug,
        set: {
          name: category.name,
          icon: category.icon,
          description: category.description,
        },
      })
      .returning();
    categoryIdBySlug.set(category.slug, row!.id);
  }

  for (const provider of providers) {
    const categoryId = categoryIdBySlug.get(provider.categorySlug);
    if (!categoryId) {
      throw new Error(`Unknown category slug: ${provider.categorySlug}`);
    }

    const [row] = await db
      .insert(providersTable)
      .values({
        categoryId,
        name: provider.name,
        businessName: provider.businessName,
        city: provider.city,
        district: provider.district,
        rating: provider.rating,
        reviewCount: provider.reviewCount,
        completedJobs: provider.completedJobs,
        avatarUrl: provider.avatarUrl,
        bio: provider.bio,
        verified: provider.verified,
        yearsExperience: provider.yearsExperience,
        startingPrice: provider.startingPrice,
      })
      .returning();

    for (const review of provider.reviews) {
      await db.insert(reviewsTable).values({
        providerId: row!.id,
        customerName: review.customerName,
        rating: review.rating,
        comment: review.comment,
      });
    }
  }

  console.log(`Seeded ${categories.length} categories and ${providers.length} providers.`);
  await pool.end();
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
