# Kapımda

A Turkish home-services marketplace (Armut-style) where customers browse verified service providers ("usta") by category and city, view reviews, and submit service requests.

## Run & Operate

The project runs as two workflows (already configured):

- **Start application** (webview, port 5000) — `cd artifacts/kapimda && PORT=5000 BASE_PATH=/ API_SERVER_PORT=8080 pnpm run dev`, the Vite dev server for the React frontend. It proxies `/api/*` to the API server (see `artifacts/kapimda/vite.config.ts`).
- **API Server** (console, port 8080) — `cd artifacts/api-server && PORT=8080 pnpm run dev`, the Express API.

Other useful commands:

- `pnpm run typecheck` — full typecheck across all packages (mockup-sandbox excluded; it's a separate canvas tool)
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/scripts run seed:kapimda` — reseed categories/providers/reviews (destructive: clears and reinserts providers/reviews)
- Required env: `DATABASE_URL` — Postgres connection string (Replit's built-in database; already provisioned)

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React 19 + Vite + Tailwind, `wouter` router
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod, `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (ESM bundle) for the API server, Vite static build for the frontend

## Where things live

- `artifacts/kapimda` — the React frontend (routes in `src/App.tsx`: `/`, `/kategori/:slug`, `/ustalar`, `/ustalar/:id`, `/hizmet-al`)
- `artifacts/api-server` — Express API, mounted under `/api` (`src/routes/`)
- `lib/db` — Drizzle schema (`src/schema/`) and DB client
- `lib/api-spec` — OpenAPI spec, source of truth for API contracts; `orval` generates `lib/api-client-react` and `lib/api-zod` from it
- `scripts/src/seed-kapimda.ts` — seed data for categories/providers/reviews (Turkish sample data)
- `artifacts/mockup-sandbox` — Canvas component-preview sandbox, unrelated to the main app

## Architecture decisions

- This project was imported as a zip export of a Replit pnpm-workspace/artifacts scaffold. The root `package.json`, `pnpm-workspace.yaml`, and `.gitignore` were not part of the export (platform-generated) and were recreated during setup — pnpm catalog versions were picked freshly, not restored from an original lockfile.
- The `artifacts/*/.replit-artifact/artifact.toml` files describe production path-based routing (frontend at `/`, API at `/api`) that Replit's artifact system would normally wire up automatically. Since artifact orchestration for `web`/`api` types isn't available in this project, local dev instead uses a Vite dev-server proxy (`/api` → `http://localhost:8080`) added in `artifacts/kapimda/vite.config.ts`.
- Frontend API calls use plain relative `fetch("/api/...")` (see `lib/api-client-react/src/custom-fetch.ts`) and assume same-origin — this only works because of the dev proxy above; a real deployment needs equivalent routing in front of both services.

## Product

- Home page with hero, service categories, and stats
- `/ustalar` — browse/filter all providers by category, city, or keyword
- `/kategori/:slug` — providers within one category
- `/ustalar/:id` — provider profile with reviews
- `/hizmet-al` — submit a service request

## User preferences

_None recorded yet._

## Gotchas

- Always run `pnpm --filter @workspace/db run push` after changing `lib/db/src/schema/*` — schema changes are not applied automatically.
- The "Hizmetler" nav link points to `/hizmetler`, which has no matching route (only `/ustalar` exists) — currently 404s.
- `pnpm run typecheck` at the root will fail on `artifacts/mockup-sandbox` unless invoked with `pnpm --filter '!@workspace/mockup-sandbox' -r run typecheck`; that package isn't wired into this project's TypeScript toolchain the same way as the others.
