import { pgTable, text, integer, timestamp } from "drizzle-orm/pg-core";

// Küçük, kalıcı sayaçlar için genel amaçlı tablo (örn. ana sayfadaki
// "Tamamlanan İş" istatistiğinin zamanla otomatik artması gibi).
export const platformCountersTable = pgTable("platform_counters", {
  key: text("key").primaryKey(),
  value: integer("value").notNull().default(0),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type PlatformCounterRow = typeof platformCountersTable.$inferSelect;
