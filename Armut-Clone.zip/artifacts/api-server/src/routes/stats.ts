import { Router, type IRouter } from "express";
import { sql } from "drizzle-orm";
import { db, categoriesTable, providersTable } from "@workspace/db";
import { GetStatsSummaryResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/stats/summary", async (_req, res): Promise<void> => {
  const [providerStats] = await db
    .select({
      totalProviders: sql<number>`count(*)::int`,
      totalCompletedJobs: sql<number>`coalesce(sum(${providersTable.completedJobs}), 0)::int`,
      totalCities: sql<number>`count(distinct ${providersTable.city})::int`,
    })
    .from(providersTable);

  const [categoryStats] = await db
    .select({ totalCategories: sql<number>`count(*)::int` })
    .from(categoriesTable);

  res.json(
    GetStatsSummaryResponse.parse({
      totalProviders: providerStats?.totalProviders ?? 0,
      totalCompletedJobs: providerStats?.totalCompletedJobs ?? 0,
      totalCategories: categoryStats?.totalCategories ?? 0,
      totalCities: providerStats?.totalCities ?? 0,
    }),
  );
});

export default router;
