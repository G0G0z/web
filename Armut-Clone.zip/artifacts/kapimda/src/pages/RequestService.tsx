import { Layout } from "@/components/layout/Layout"
import { useCreateServiceRequest, useListCategories } from "@workspace/api-client-react"
import { useSearch, useLocation } from "wouter"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { CheckCircle2, Loader2, ArrowRight } from "lucide-react"
import { useState } from "react"
import { useToast } from "@/hooks/use-toast"

const formSchema = z.object({
  categorySlug: z.string().min(1, { message: "Lütfen bir hizmet kategorisi seçin." }),
  customerName: z.string().min(2, { message: "Ad soyad en az 2 karakter olmalıdır." }),
  customerPhone: z.string().min(10, { message: "Geçerli bir telefon numarası giriniz." }),
  city: z.string().min(2, { message: "Şehir alanı zorunludur." }),
  district: z.string().optional(),
  description: z.string().min(10, { message: "Lütfen ihtiyacınızı biraz daha detaylı açıklayın." }),
})

export default function RequestService() {
  const searchString = useSearch()
  const [, setLocation] = useLocation()
  const queryParams = new URLSearchParams(searchString)
  const initialCategory = queryParams.get("kategori") || ""
  
  const { toast } = useToast()
  const { data: categories } = useListCategories()
  const createRequest = useCreateServiceRequest()
  const [isSuccess, setIsSuccess] = useState(false)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      categorySlug: initialCategory,
      customerName: "",
      customerPhone: "",
      city: "",
      district: "",
      description: "",
    },
  })

  // Cities mock data
  const cities = ["İstanbul", "Ankara", "İzmir", "Bursa", "Antalya", "Adana"]

  function onSubmit(values: z.infer<typeof formSchema>) {
    createRequest.mutate({ data: values }, {
      onSuccess: () => {
        setIsSuccess(true)
        window.scrollTo({ top: 0, behavior: 'smooth' })
      },
      onError: () => {
        toast({
          variant: "destructive",
          title: "Bir hata oluştu",
          description: "Talebiniz gönderilirken bir sorun yaşandı. Lütfen tekrar deneyin.",
        })
      }
    })
  }

  if (isSuccess) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-24 min-h-[70vh] flex flex-col items-center justify-center">
          <div className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-8 animate-in zoom-in duration-500 shadow-xl shadow-green-100/50">
            <CheckCircle2 className="w-12 h-12" />
          </div>
          <h1 className="text-4xl font-display font-bold text-center mb-4 text-foreground">
            Talebiniz Başarıyla Alındı!
          </h1>
          <p className="text-lg text-muted-foreground text-center max-w-lg mb-10 leading-relaxed">
            Hizmet talebiniz bölgenizdeki ilgili ustalara iletildi. En kısa sürede en uygun ustalar sizinle iletişime geçecek.
          </p>
          <div className="flex gap-4">
            <Button size="lg" onClick={() => setLocation("/")} variant="outline" className="rounded-2xl">
              Ana Sayfaya Dön
            </Button>
            <Button size="lg" onClick={() => setLocation("/ustalar")} className="rounded-2xl shadow-lg shadow-primary/20">
              Hizmetleri İncele
            </Button>
          </div>
        </div>
      </Layout>
    )
  }

  return (
    <Layout>
      <div className="bg-primary/5 border-b border-border">
        <div className="container mx-auto px-4 py-12 md:py-16 text-center max-w-3xl">
          <h1 className="text-3xl md:text-5xl font-display font-bold mb-4">Hizmet Talebi Oluştur</h1>
          <p className="text-lg text-muted-foreground">İhtiyacınızı detaylıca anlatın, güvenilir ustalarımız size hızlıca ulaşsın.</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          <Card className="border-border/50 shadow-xl overflow-visible">
            <div className="h-2 w-full bg-gradient-to-r from-primary to-accent rounded-t-2xl" />
            <CardHeader className="px-8 pt-8 pb-6 border-b border-border/50">
              <CardTitle className="text-2xl">Talep Formu</CardTitle>
              <CardDescription className="text-base">Lütfen tüm bilgileri eksiksiz doldurun.</CardDescription>
            </CardHeader>
            
            <CardContent className="p-8">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  
                  <div className="space-y-6 p-6 bg-secondary/30 rounded-2xl border border-secondary">
                    <h3 className="font-display font-bold flex items-center text-foreground">
                      <span className="w-6 h-6 rounded-full bg-primary text-white flex items-center justify-center text-xs mr-3">1</span>
                      Hizmet Detayları
                    </h3>
                    
                    <FormField
                      control={form.control}
                      name="categorySlug"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Hizmet Kategorisi</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger className="bg-background h-12">
                                <SelectValue placeholder="Neye ihtiyacınız var?" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {categories?.map((cat) => (
                                <SelectItem key={cat.slug} value={cat.slug}>
                                  {cat.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>İşin Detayları</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Yapılacak işi, varsa sorunu veya özel isteklerinizi buraya yazın..." 
                              className="bg-background min-h-[120px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="space-y-6 p-6 bg-secondary/30 rounded-2xl border border-secondary mt-8">
                    <h3 className="font-display font-bold flex items-center text-foreground">
                      <span className="w-6 h-6 rounded-full bg-primary text-white flex items-center justify-center text-xs mr-3">2</span>
                      İletişim & Konum
                    </h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="customerName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Ad Soyad</FormLabel>
                            <FormControl>
                              <Input placeholder="Adınız Soyadınız" className="bg-background h-12" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="customerPhone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Telefon Numarası</FormLabel>
                            <FormControl>
                              <Input placeholder="05XX XXX XX XX" type="tel" className="bg-background h-12" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="city"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Şehir</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="bg-background h-12">
                                  <SelectValue placeholder="Şehir Seçin" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {cities.map((c) => (
                                  <SelectItem key={c} value={c}>{c}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="district"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>İlçe</FormLabel>
                            <FormControl>
                              <Input placeholder="Örn: Kadıköy" className="bg-background h-12" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  <div className="pt-6">
                    <Button 
                      type="submit" 
                      size="lg" 
                      className="w-full h-14 text-lg rounded-2xl shadow-lg shadow-primary/20 group"
                      disabled={createRequest.isPending}
                    >
                      {createRequest.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                          Gönderiliyor...
                        </>
                      ) : (
                        <>
                          Talebi Gönder
                          <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                        </>
                      )}
                    </Button>
                    <p className="text-center text-sm text-muted-foreground mt-4">
                      Talebinizi göndererek <span className="underline cursor-pointer">Kullanım Şartları</span>'nı kabul etmiş olursunuz.
                    </p>
                  </div>

                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  )
}
