import { Layout } from "@/components/layout/Layout"
import { useListProviders, useListCategories } from "@workspace/api-client-react"
import { Link, useSearch } from "wouter"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Star, ShieldCheck, MapPin, Search, SlidersHorizontal, Loader2, ArrowRight } from "lucide-react"
import { useState, useEffect } from "react"
import { useDebounce } from "@/hooks/use-debounce"

export default function Providers() {
  const searchString = useSearch()
  const queryParams = new URLSearchParams(searchString)
  
  const [search, setSearch] = useState(queryParams.get("search") || "")
  const debouncedSearch = useDebounce(search, 500)
  
  const [category, setCategory] = useState<string>(queryParams.get("category") || "all")
  const [city, setCity] = useState<string>(queryParams.get("city") || "all")

  const { data: categories } = useListCategories()
  
  const { data: providers, isLoading } = useListProviders({
    search: debouncedSearch || undefined,
    category: category !== "all" ? category : undefined,
    city: city !== "all" ? city : undefined,
  })

  // Cities mock data - in a real app this would come from API
  const cities = ["İstanbul", "Ankara", "İzmir", "Bursa", "Antalya", "Adana"]

  return (
    <Layout>
      <div className="bg-card border-b border-border py-8">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-display font-bold mb-6">Ustaları Keşfet</h1>
          
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            <div className="md:col-span-5 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input 
                placeholder="Usta adı, hizmet veya anahtar kelime..." 
                className="pl-12 h-14 text-base rounded-2xl bg-background"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            
            <div className="md:col-span-3">
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="h-14 bg-background rounded-2xl text-base">
                  <SelectValue placeholder="Kategori Seçin" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tüm Kategoriler</SelectItem>
                  {categories?.map((cat) => (
                    <SelectItem key={cat.slug} value={cat.slug}>{cat.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="md:col-span-3">
              <Select value={city} onValueChange={setCity}>
                <SelectTrigger className="h-14 bg-background rounded-2xl text-base">
                  <SelectValue placeholder="Şehir Seçin" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tüm Şehirler</SelectItem>
                  {cities.map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="md:col-span-1">
              <Button size="icon" variant="outline" className="w-full h-14 rounded-2xl bg-background border-border">
                <SlidersHorizontal className="w-5 h-5 text-muted-foreground" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="mb-8 flex items-center justify-between">
          <p className="text-muted-foreground font-medium">
            <span className="text-foreground font-bold">{providers?.length || 0}</span> usta bulundu
          </p>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center min-h-[40vh]">
            <Loader2 className="w-10 h-10 animate-spin text-primary" />
          </div>
        ) : providers && providers.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {providers.map((provider) => (
              <Link key={provider.id} href={`/ustalar/${provider.id}`}>
                <Card className="group hover:shadow-lg transition-all duration-300 hover:border-primary/30 flex flex-col sm:flex-row overflow-hidden h-full">
                  <div className="w-full sm:w-48 h-48 sm:h-auto bg-muted relative shrink-0">
                    {provider.avatarUrl ? (
                      <img src={provider.avatarUrl} alt={provider.businessName} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-primary/10 flex items-center justify-center">
                        <span className="font-display font-bold text-5xl text-primary/30">{provider.businessName.charAt(0)}</span>
                      </div>
                    )}
                    {provider.verified && (
                      <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-primary flex items-center gap-1.5 shadow-sm">
                        <ShieldCheck className="w-4 h-4" /> Onaylı
                      </div>
                    )}
                  </div>
                  
                  <CardContent className="p-6 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="font-display font-bold text-xl mb-1 group-hover:text-primary transition-colors">
                            {provider.businessName}
                          </h3>
                          <Badge variant="outline" className="bg-card">{provider.categoryName}</Badge>
                        </div>
                        <div className="flex items-center gap-1 bg-accent/10 text-accent-foreground px-2 py-1 rounded-md font-bold">
                          <Star className="w-4 h-4 fill-accent text-accent" />
                          {provider.rating.toFixed(1)}
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-2 my-4">
                        {provider.bio || `${provider.categoryName} alanında ${provider.yearsExperience} yıllık tecrübem ile hizmet veriyorum. İşimi özenle ve titizlikle yaparım.`}
                      </p>
                    </div>

                    <div className="flex items-center justify-between mt-auto pt-4 border-t border-border/50">
                      <div className="flex items-center gap-4 text-sm font-medium">
                        <div className="flex items-center gap-1.5 text-muted-foreground">
                          <MapPin className="w-4 h-4" />
                          {provider.district ? `${provider.district}, ` : ''}{provider.city}
                        </div>
                      </div>
                      <div className="text-primary font-medium flex items-center gap-1 text-sm group-hover:translate-x-1 transition-transform">
                        Profili Gör <ArrowRight className="w-4 h-4" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-32 bg-card rounded-3xl border border-border border-dashed">
            <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <h3 className="text-2xl font-display font-bold mb-2">Usta bulunamadı</h3>
            <p className="text-muted-foreground mb-6 max-w-md mx-auto">Arama kriterlerinize uygun usta bulamadık. Lütfen farklı kelimeler deneyin veya filtreleri temizleyin.</p>
            <Button onClick={() => { setSearch(""); setCategory("all"); setCity("all"); }} variant="outline">
              Filtreleri Temizle
            </Button>
          </div>
        )}
      </div>
    </Layout>
  )
}
